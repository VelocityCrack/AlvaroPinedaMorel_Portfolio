using UnityEngine;

public class Ejercicio2Script : MonoBehaviour
{
    public float speedX;
    public float speedY;
    public float speedZ;

    Rigidbody rb;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        rb.angularVelocity = new Vector3(speedX, speedY, speedZ);
    }
}
