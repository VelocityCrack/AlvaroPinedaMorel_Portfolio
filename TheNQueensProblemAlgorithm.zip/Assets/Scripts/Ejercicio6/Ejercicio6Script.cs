using UnityEngine;

public class Ejercicio6Script : MonoBehaviour
{
    public float speed;

    Rigidbody rb;
    Renderer material;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        material = GetComponent<Renderer>();
    }

    // Update is called once per frame
    void Update()
    {
        rb.linearVelocity = transform.forward * speed;
    }

    private void OnCollisionEnter(Collision collision)
    {
        transform.Rotate(new Vector3(0, 180, 0));
        material.material.color = Random.ColorHSV();
    }
}
