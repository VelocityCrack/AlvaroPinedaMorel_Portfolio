using UnityEngine;

public class Ejercicio6Script2 : MonoBehaviour
{
    public GameObject OtroGO;
    public float radioDeCambio;
    private bool canChangeColor;
    private Renderer material;

    private void Start()
    {
        material = GetComponent<Renderer>();
    }

    // Update is called once per frame
    void Update()
    {
        if (canChangeColor)
        {
            if ((OtroGO.transform.position - transform.position).magnitude <= radioDeCambio)
            {
                material.material.color = Random.ColorHSV();
                canChangeColor = false;
            }
        } else
        {
            if ((OtroGO.transform.position - transform.position).magnitude > radioDeCambio)
            {
                canChangeColor = true;
            }
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(transform.position, radioDeCambio);
    }
}
