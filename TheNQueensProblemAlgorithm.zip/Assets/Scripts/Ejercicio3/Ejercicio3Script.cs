using UnityEngine;

public class Ejercicio3Script : MonoBehaviour
{
    public float speed;
    bool goingToWaypoint;

    Rigidbody rb;
    public GameObject OriginalPosGO;
    public GameObject WaypointGO;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        if (goingToWaypoint)
        {
            Vector3 dir = WaypointGO.transform.position - transform.position;
            rb.linearVelocity = dir.normalized * speed;
        } else
        {
            Vector3 dir = OriginalPosGO.transform.position - transform.position;
            rb.linearVelocity = dir.normalized * speed;
        }   
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Waypoint"))
        {
            goingToWaypoint = false;
        } 
        else if (other.CompareTag("OriginalPos"))
        {
            goingToWaypoint = true;
        }
    }
}
