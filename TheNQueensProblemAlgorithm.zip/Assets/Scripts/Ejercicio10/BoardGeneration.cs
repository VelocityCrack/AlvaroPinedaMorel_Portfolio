using System;
using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UIElements;
using Random = UnityEngine.Random;

public class BoardGeneration : MonoBehaviour
{
    [Header("Changes board size")]
    public int boardSize = 8;

    [Header("Don't touch")]
    private int numQueens;
    private bool resetingBoard;
    private bool processing;

    private int[] queensPosAlg;      //Columns are stored as the position in the array and rows are the value. (It goes from 0 to 7 in a 8x8 board.)

    public GameObject[,] board;
    public GameObject Tile_GO;
    public GameObject Queen_GO;
    public Material[] QueensMaterials = new Material[8];
    public Material brownMat;
    public Material whiteMat;
    public Material redMat; //Indicates queen threats collision.
    public Material greyMat; //Indicates queen threats.

    public GameObject boardParent;
    public GameObject queensParent;


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        processing = true;
        InitBoard();
        QueensAlgorithm();
    }

    private void InitBoard()
    {
        board = new GameObject[boardSize, boardSize]; 
        numQueens = boardSize;
        queensPosAlg = new int[numQueens];

        for (int i = 0; i < boardSize; i++) // Vertical
        {
            for (int j = 0; j < boardSize; j++) //Horizontal
            {
                GameObject Tile = Instantiate(Tile_GO, new Vector3(boardSize - (j + 1), 0, i), Quaternion.identity);
                board[boardSize - j - 1, boardSize - i - 1] = Tile;

                if (j % 2 == 0 && i % 2 == 1 || j % 2 == 1 && i % 2 == 0)
                {
                    Tile.GetComponent<Renderer>().material = whiteMat;
                }
                else
                {
                    Tile.GetComponent<Renderer>().material = brownMat;
                }
                Tile.transform.parent = boardParent.transform;
            }
        }
    }

    private void PlaceRandomQueen()
    {
        GameObject Queen = Instantiate(Queen_GO, new Vector3(Random.Range(0, boardSize), 1, Random.Range(0, boardSize)), Quaternion.identity);
        Queen.transform.parent = queensParent.transform;
        Material queenMat = QueensMaterials[Random.Range(0, QueensMaterials.Length)];

        DrawTiles(new Vector2Int((int)Queen.transform.position.x, (int)Queen.transform.position.z), queenMat);

    }


   private void PlaceQueens()
   {
       for(int i = 0; i < numQueens; i++)
       {
            GameObject Queen = Instantiate(Queen_GO, new Vector3(queensPosAlg[i], 1, i), Quaternion.identity);
            Queen.transform.parent = queensParent.transform;

            Material queenMat = QueensMaterials[((i % 8) + 8) % 8];

            DrawTiles(new Vector2Int((int)Queen.transform.position.x, (int)Queen.transform.position.z), queenMat);
       }
   }

   private void QueensAlgorithm()
   {
        int queensPlacedProxi = 0;
        Vector2Int[] diagPos = new Vector2Int[numQueens];   
        Vector2Int[] diagNeg = new Vector2Int[numQueens];   

        Array.Fill<int>(queensPosAlg, -2);
        Array.Fill<Vector2Int>(diagPos, new Vector2Int(-2, -2));
        Array.Fill<Vector2Int>(diagNeg, new Vector2Int(-2, -2));
       
        int firstQueenRow = Random.Range(0, boardSize);  //The first queen's position is random.

        queensPosAlg[queensPlacedProxi] = firstQueenRow;
        diagPos[queensPlacedProxi] = CalculateDiagPos(new Vector2Int(queensPlacedProxi, queensPosAlg[queensPlacedProxi]), CalculateReflexQueenPosY(queensPosAlg[queensPlacedProxi]));
        diagNeg[queensPlacedProxi] = CalculateDiagNeg(new Vector2Int(queensPlacedProxi, queensPosAlg[queensPlacedProxi]), CalculateReflexQueenPosY(queensPosAlg[queensPlacedProxi]));

        queensPlacedProxi++;

        for (int i = 0; queensPlacedProxi < numQueens;)
        {
            if (queensPlacedProxi == numQueens)  //If all queens have founded a valid position.
            {
                break;
            }

            if (i >= numQueens)
            {
                i = queensPosAlg[queensPlacedProxi - 1] + 1;
                queensPosAlg[queensPlacedProxi] = -2;
                diagPos[queensPlacedProxi] = new Vector2Int(-2, -2);
                diagNeg[queensPlacedProxi] = new Vector2Int(-2, -2);
                queensPlacedProxi--;
            }
            else if (!FindObjectInArray<Vector2Int>(diagPos, CalculateDiagPos(new Vector2Int(queensPlacedProxi, i), CalculateReflexQueenPosY(i))) && !FindObjectInArray<Vector2Int>(diagNeg, CalculateDiagNeg(new Vector2Int(queensPlacedProxi, i), CalculateReflexQueenPosY(i))) && !FindObjectInArray<int>(queensPosAlg, i))
            {
                queensPosAlg[queensPlacedProxi] = i;
                diagPos[queensPlacedProxi] = CalculateDiagPos(new Vector2Int(queensPlacedProxi, queensPosAlg[queensPlacedProxi]), CalculateReflexQueenPosY(queensPosAlg[queensPlacedProxi]));
                diagNeg[queensPlacedProxi] = CalculateDiagNeg(new Vector2Int(queensPlacedProxi, queensPosAlg[queensPlacedProxi]), CalculateReflexQueenPosY(queensPosAlg[queensPlacedProxi]));

                queensPlacedProxi++;
                i = 0;
            }
            else
            {
                i++;
            }
        }

        PlaceQueens();
   }

    private bool FindObjectInArray<T>(T[] vector, T value)
    {
        if (Array.IndexOf(vector, value) == -1)
        {
            return false; 
        } else
        {
            return true;
        }

        //return Array.IndexOf(vector, value) != -1 ? true : false;
    }

    #region Calculate Tails

    private Vector2Int CalculateDiagPos(Vector2Int queenPos, int reflexQueenPosY)     //Devuelve la casilla inferior izquieda de la diagonal positiva.
    {
        Vector2Int tilePos = new Vector2Int();

        if (queenPos.x >= queenPos.y)
        {
            tilePos.x = queenPos.x - queenPos.y;
            tilePos.y = boardSize - 1;
        }
        else
        {
            tilePos.x = 0;
            tilePos.y = reflexQueenPosY + queenPos.x;
        }

        return tilePos;
    }

    private Vector2Int CalculateDiagNeg(Vector2Int queenPos, int reflexQueenPosY)    //Devuelve la casilla inferior derecha de la diagonal negativa.
    {
        Vector2Int tilePos = new Vector2Int();

        if (boardSize - 1 - queenPos.x >= queenPos.y)
        {
            tilePos.x = queenPos.x + queenPos.y;
            tilePos.y = boardSize - 1;
        }
        else
        {
            tilePos.x = boardSize - 1;
            tilePos.y = reflexQueenPosY + (boardSize - 1 - queenPos.x);
        }

        return tilePos;
    }

    private int CalculateRow(Vector2Int queenPos, int reflexQueenPosY)  //Devuelve la columna.
    {
        int row = reflexQueenPosY;

        return row;
    }

    private int CalculateColumn(Vector2Int queenPos)  //Devuelve fila seg�n la varible "board" en esa columna (es decir, la de arriba del todo).
    {
        int column = queenPos.x;

        return column;
    }

    private int CalculateReflexQueenPosY(int queenPosY)
    {
        int reflexQueenPosY = boardSize - 1 - queenPosY;

        return reflexQueenPosY;
    }

    #endregion

    private void ResetBoard()
    {
        for (int i = 0; i < boardParent.transform.childCount; i++)
        {
            Destroy(boardParent.transform.GetChild(i).gameObject);
        }

        for (int i = 0; i < queensParent.transform.childCount; i++)
        {
            Destroy(queensParent.transform.GetChild(i).gameObject);
        }
    }

    private void DrawTiles(Vector2Int queenPos, Material queenMat)
    {
        Material tileOriginalMat;
        int reflexQueenPosY = CalculateReflexQueenPosY(queenPos.y);

        Vector2Int diagPosTilePos = CalculateDiagPos(queenPos, reflexQueenPosY);
        Vector2Int diagNegTilePos = CalculateDiagNeg(queenPos, reflexQueenPosY);
        int rowTilePos = CalculateRow(queenPos, reflexQueenPosY);
        int columnTilePos = CalculateColumn(queenPos);


        for (int i = 0; i < boardSize; i++) //Draw row
        {
           tileOriginalMat = board[i, rowTilePos].GetComponent<Renderer>().sharedMaterial;
           
           if (tileOriginalMat == whiteMat || tileOriginalMat == brownMat)
           {
               board[i, reflexQueenPosY].GetComponent<Renderer>().material = queenMat;
           } else if (tileOriginalMat == greyMat)
           {
               board[i, reflexQueenPosY].GetComponent<Renderer>().material = redMat;
           }
        }

        for (int j = 0; j < boardSize; j++) //Draw column
        {
           tileOriginalMat = board[columnTilePos, j].GetComponent<Renderer>().sharedMaterial;
           
           if (tileOriginalMat == whiteMat || tileOriginalMat == brownMat)
           {
               board[queenPos.x, j].GetComponent<Renderer>().material = queenMat;
           }
           else if (tileOriginalMat == greyMat)
           {
               board[queenPos.x, j].GetComponent<Renderer>().material = redMat;
           }
        }


        int k = diagPosTilePos.y;
        int l = diagPosTilePos.x;

        while (k >= 0 && l < boardSize)      //Draw positive diagonal
        {
            board[l, k].GetComponent<Renderer>().material = queenMat;

            k--;
            l++;
        }


        int m = diagNegTilePos.y;
        int n = diagNegTilePos.x;

        while (m >= 0 && n >= 0)     //Draw negative diagonal
        {
            board[n, m].GetComponent<Renderer>().material = queenMat;

            m--;
            n--;
        }

        processing = false;
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && !processing)
        {
            processing = true;
            ResetBoard();
            InitBoard();
            QueensAlgorithm();
        }

        if (Input.GetKeyDown(KeyCode.V) && !processing)
        {
            PlaceRandomQueen();
        }

        if (Input.GetKeyDown(KeyCode.X) && !processing)
        {
            ResetBoard();
            InitBoard();
        }
    }

}
