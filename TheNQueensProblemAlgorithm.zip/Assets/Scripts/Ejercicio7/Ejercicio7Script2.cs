using UnityEngine;

public class Ejercicio7Script2 : MonoBehaviour
{
    public enum Puertas
    {
        Puerta1, Puerta2, Puerta3
    }

    public GameObject[] puertas;
    public Puertas doorToDestroy;

    public void OnButtonPress()
    {
        Destroy(puertas[((int)doorToDestroy)]);
    }
}
