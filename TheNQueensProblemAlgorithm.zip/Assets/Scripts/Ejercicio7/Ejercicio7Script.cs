using UnityEngine;

public class Ejercicio7Script : MonoBehaviour
{
    public float sizeRatio;

    private void OnTriggerEnter(Collider other)
    {
        other.transform.localScale += new Vector3(sizeRatio, sizeRatio, sizeRatio);
        Destroy(gameObject);
    }
}
