using Unity.VisualScripting;
using UnityEngine;

public class Ejercicio4Script2 : MonoBehaviour
{

    public float speed;
    bool goingToWaypoint;
    public GameObject[] WaypointsGO;
    private int nextWaypoint;

    Rigidbody rb;


    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        nextWaypoint = Random.Range(0, WaypointsGO.Length);
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 dir = WaypointsGO[nextWaypoint].transform.position - transform.position;
        rb.linearVelocity = dir.normalized * speed;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Waypoint"))
        {
            int a = nextWaypoint;
            
            while (nextWaypoint == a)
            nextWaypoint = Random.Range(0, WaypointsGO.Length);
        }
    }
}
