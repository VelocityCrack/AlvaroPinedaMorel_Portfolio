using UnityEngine;

public class Ejercicio4Script : MonoBehaviour
{
    public float speed;
    bool goingToWaypoint;
    [Range(1, 5)] public int initWaypoint;
    public GameObject[] WaypointsGO;
    private int nextWaypoint;

    Rigidbody rb;


    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        nextWaypoint = initWaypoint;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 dir = WaypointsGO[nextWaypoint - 1].transform.position - transform.position;
        rb.linearVelocity = dir.normalized * speed;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Waypoint"))
        {
            nextWaypoint++;

            if (nextWaypoint > WaypointsGO.Length)
            {
                nextWaypoint = 1;
            }
        }
    }
}
