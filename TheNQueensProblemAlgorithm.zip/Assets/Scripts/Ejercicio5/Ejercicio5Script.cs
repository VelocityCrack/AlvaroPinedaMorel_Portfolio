using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class Ejercicio5Script : MonoBehaviour
{
    public GameObject Brick_GO;
    public float secondsBetweenBricks;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        StartCoroutine(MakeWall());
    }


    private IEnumerator MakeWall()
    {
        float filas = 0;
        float columnas = 0;

        for (int i = 0; i < 38; i++)
        {
            if (i == 5 || i == 11 || i == 16 || i == 22 || i == 27 || i == 33) filas += 0.5f;
            if (i == 5 || i == 16 || i == 27)
            {
                columnas = -0.5f;
            } else if (i == 11 || i == 22 ||i == 33)
            {
                columnas = 0;
            }

            Instantiate(Brick_GO, new Vector3(columnas, filas, 0), Quaternion.identity);
            columnas++;

            yield return new WaitForSeconds(secondsBetweenBricks);
        }
    }
}
