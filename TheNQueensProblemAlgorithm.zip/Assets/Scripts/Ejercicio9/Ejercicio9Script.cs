using UnityEngine;

public class Ejercicio9Script : MonoBehaviour
{
    public static Ejercicio9Script Instance { get; private set; }  
    public bool explotar = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        if (Instance == null)
        {
            Instance = this;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            explotar = true;
        } 
    }
}
