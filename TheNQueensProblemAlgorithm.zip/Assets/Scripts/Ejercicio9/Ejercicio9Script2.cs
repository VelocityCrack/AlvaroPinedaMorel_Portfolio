using UnityEngine;

public class Ejercicio9Script2 : MonoBehaviour
{
    void Update()
    {
        if (Ejercicio9Script.Instance.explotar)
        {
            Destroy(gameObject);
        }
    }
}
