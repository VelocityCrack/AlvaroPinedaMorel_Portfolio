using UnityEngine;

public class Ejercicio8Script : MonoBehaviour
{
    public GameObject OtroObjeto_GO;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float angle = Vector3.Angle(transform.forward, OtroObjeto_GO.transform.position - transform.position);


        print(angle);

    }
}
